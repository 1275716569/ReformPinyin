// WeaselSetup.h
